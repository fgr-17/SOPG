gcc -pthread main.c rs232.c SerialManager.c -o serialService
