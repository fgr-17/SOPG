#define PREFIJO_TEXTO           "DATA"
#define PREFIJO_SIGUSRx         "SIGN"

#define MENSAJE_SIGUSR1         "1"
#define MENSAJE_SIGUSR2         "2"

#define CADENA_DELIM            ":"
#define CADENA_L                300
